
package mypackage;

import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.MainScreen;

/**
 * A class extending the MainScreen class, which provides default standard
 * behavior for BlackBerry GUI applications.
 */
public final class MyScreen extends MainScreen
{
    /**
     * Creates a new MyScreen object
     */
        public MyScreen()
    {        
        // Set the displayed title of the screen       
        setTitle("Assignment 2 -- Set 2");
    }
    public void updateStatus(String stat)
    {
        LabelField lab= new LabelField();
        lab.setText(stat);
        add(lab);
    }
}
 
