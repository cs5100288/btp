package in.ac.iitd.csl374;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BtContacts extends Activity {
    
 
    OnClickListener listener;
    Button buttonStart, buttonStop;
	
	//Set<String> macs;
//	PendingIntent pendingIntent =  PendingIntent.getService (BtContacts.this, 0, new Intent(BtContacts.this, Columbus.class), 0);
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.main);
//        Log.e("Rajat","After Set View");
        
        
        
        startBluetooth();
        
        buttonStart = (Button)findViewById(R.id.buttonStart);
        buttonStop = (Button)findViewById(R.id.buttonStop);
//        Log.e("Rajat","after detect bluetooth");
        listener = new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				switch( arg0.getId()){
				case R.id.buttonStart :
					Log.e("Rajat", "start button clicked");
					startService(new Intent(BtContacts.this, BtContactService.class));
					break;
				case R.id.buttonStop:
					Log.e("Rajat", "stop button clicked");
					stopService(new Intent(BtContacts.this, BtContactService.class));
					break;
				}
			}
		};
        
        
        
        
        
    }
    
    @Override
    protected void onPause() {
    	// TODO Auto-generated method stub
    	Log.e("Rajat", "Paused");
    	super.onPause();
    	buttonStart.setOnClickListener(null);
    	buttonStop.setOnClickListener(null);
    	
    	
    }
    
    @Override
    protected void onResume() {
    	// TODO Auto-generated method stub
    	Log.e("Rajat", "Resumed");
    	super.onResume();
    	buttonStart.setOnClickListener(listener);
    	buttonStop.setOnClickListener(listener);
    }
    
    void startBluetooth()
    {
    	BluetoothAdapter mAdapter= BluetoothAdapter.getDefaultAdapter();
    	
    	//Log.e("Rajat","My Mac is : "+selfMac);
//    	Log.e("Rajat","After get adapter");
    	if(mAdapter==null)
    	{
//    		Log.e("Rajat","Adapter null");
    		return;
    	}
    	else if(!mAdapter.isEnabled())
    	{
//    		Log.e("Rajat","Enabling");
    		Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    	    startActivityForResult(enableBtIntent, 3);
    	}

    }
}
