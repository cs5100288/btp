package mypackage;

import java.io.IOException;
import java.util.Date;

import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;
import javax.microedition.io.UDPDatagramConnection;

/**
 * This class represents the client in our client/server configuration.
 */
public final class PacketTrain
{    
	private String _destination;
    private MyScreen _screen;  
    private UDPDatagramConnection _conn;  
//    private int _timeSpace;
    private int _padlength;
    private int _packetNumber;
    private int _id;
    private String _sentence1,_sentence2;
    private long _sendTime1,_sendTime2;
    /**
     * Creates a new UdpClient.
     * @param msg The message sent to the server.
     */
    public PacketTrain(MyScreen scr,String dest,int id,int padlength,int packetNumber,String sent1,String sent2)
    {
        _screen = scr;  
        _destination=dest;
        _padlength=padlength;
        _id=id;
        _packetNumber=packetNumber;
        _sentence1=sent1;
        _sentence2=sent2;
//        _timeSpace = timeGap;
    }
    /**
     * Implementation of Thread
     */
    public void runTrain()
    {
    	
        try
        {
            _conn = (UDPDatagramConnection)Connector.open(_destination);
            String padding="";
//            _screen.updateStatus("Made a 	udp connection\n");
    		for(int i=0;i<_padlength;i++)
    		{
    			padding+=" ";
    		}
    		byte [ ] bufOut1 = _sentence1.getBytes();
    		Datagram outDatagram1 = _conn.newDatagram(bufOut1, bufOut1.length);
    		_sendTime1 = (new Date()).getTime();
            _conn.send(outDatagram1);
//            Thread.sleep(_timeSpace);
    		for(int i=0;i<_packetNumber;i++)
    		{
//    			_screen.updateStatus("Sent packet number "+i);
    			String sentence="Method: ECHO\nId: " + _id + "\nSeqno: " + (2+i) + "\nLength: 0\n"+padding+"\n";
                // Convert the message to a byte array for sending.
                byte [ ] bufOut = sentence.getBytes();
                // Create a datagram and send it across the connection.
                Datagram outDatagram = _conn.newDatagram(bufOut, bufOut.length);
                _conn.send(outDatagram);
//                Thread.sleep(_timeSpace);
    		}
    		byte [ ] bufOut2 = _sentence2.getBytes();
    		Datagram outDatagram2 = _conn.newDatagram(bufOut2, bufOut2.length);
    		_sendTime2 = (new Date()).getTime();
            _conn.send(outDatagram2);
    		
        }
        catch(IOException ioe)
        {
            final String error = ioe.toString();
            _screen.updateStatus(error);  
        }
//        catch(InterruptedException ioe)
//        {
//            final String error = ioe.toString();
//            _screen.updateStatus(error);  
//        }
        
        finally
        {
            try
            {
                // Close the connection
                _conn.close();  
            }
            catch(IOException ioe)
            {                
            }
        }
    }      
    public long sendtime1()
    {
    	return _sendTime1;
    }
    public long sendtime2()
    {
    	return _sendTime2;
    }
}
