package mypackage;

import java.io.IOException;
import java.util.Date;

import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;
import javax.microedition.io.UDPDatagramConnection;

/**
 * This class represents the client in our client/server configuration.
 */
public final class UdpClient extends Thread
{    
	private String _destination;
	private String response_string;
    private String _msg;
    private MyScreen _screen;  
    private UDPDatagramConnection _conn;  
    private long sendTime;
    private boolean _isReady;
    private boolean _isPacketTrain;
    /**
     * Creates a new UdpClient.
     * @param msg The message sent to the server.
     */
    public UdpClient(String msg,MyScreen scr,String dest,boolean isEcho)
    {
        _msg = msg;             
        _screen = scr;  
        _destination=dest;
        _isReady = false;
        _isPacketTrain = isEcho;
    }
    private String split(String input,char knife,int j)
    {
        String temp="";
        int begin=0;
        int nthknife=0;
    	for(int i=0;i<input.length();i++)
    	{
    		if(input.charAt(i)==knife)
    		{
    			nthknife++;
    			if(nthknife==j) return input.substring(begin, i);
    			begin=i+1;
    			temp="";
    		}
    		
    	}
    	return temp;
    }
    private String[] split(String input,char knife)
    {
        String[] output=new String[getNumOf(input,knife)+1];
        
        int begin=0;
        int nthknife=0;
    	for(int i=0;i<input.length();i++)
    	{
    		if(input.charAt(i)==knife)
    		{		
    			output[nthknife]=input.substring(begin, i);
    			//_screen.updateStatus(output[nthknife]);
    			begin=i+1;
    			nthknife++;
    		}
    	}
    	output[nthknife]=input.substring(begin+1);
    	return output;
    }
    public int getNumOf(String input,char knife)
    {
    	int count=0;
    	for(int i=0;i<input.length();i++)
    	{
    		if(input.charAt(i)==knife) count++;
    	}
    	return count;
    }
    public double gettime_echo() throws InterruptedException
    {
       while (!_isReady)  
       {
    	   Thread.sleep(50);
       }   
       return Double.parseDouble(split(response_string,'\n',4).substring(5));
       
       
    }
    public double[] gettime_stat() throws InterruptedException
    {
    	_screen.updateStatus(""+_isReady);
    	while (!_isReady)  
        {
     	   Thread.sleep(50);
        }
    	String[] lines=split(response_string,'\n');
    	for (int i=0;i<lines.length;i++)
    	{
    		_screen.updateStatus(i+". "+ lines[i]);
    	}
    	int len=getNumOf(response_string,'\n')-1;
    	_screen.updateStatus("length::"+len);
    	double[] output=new double[len];
    	for(int i=0;i<len;i++)
    	{
    		output[i]=Double.parseDouble(lines[i+2].substring(8+(int)((i+1)/10)));
    	}
    	_screen.updateStatus("final time : "+output[len-1]);
    	   	return output;
    }
    /**
     * Implementation of Thread
     */
    public void run()
    {
    	
        try
        {
            _conn = (UDPDatagramConnection)Connector.open(_destination);           
            byte [ ] bufOut = _msg.getBytes();
            Datagram outDatagram = _conn.newDatagram(bufOut, bufOut.length);
            
            sendTime = (new Date()).getTime();
            _conn.send(outDatagram);
            if(!_isPacketTrain)
            {	
            	// Expect a response
            	byte[] bufIn = new byte[600];    //pack train of length 41 has return pack size of 595..         
            	Datagram inDatagram = _conn.newDatagram(bufIn, bufIn.length);
            	_conn.receive(inDatagram);
            	
            	response_string = new String(inDatagram.getData());
            	_isReady = true;
            }
        }
        catch(IOException ioe)
        {
            final String error = ioe.toString();
            _screen.updateStatus(error);  
            sendTime = -1;
        }
        finally
        {
            try
            {
                _conn.close();  
            }
            catch(IOException ioe)
            {                
            }
        }
    }      
    public long getSendTime()
    {
    	return sendTime;
    }
}
