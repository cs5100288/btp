package mypackage;

import java.io.IOException;

import javax.microedition.location.Criteria;
import javax.microedition.location.Location;
import javax.microedition.location.LocationException;
import javax.microedition.location.LocationListener;
import javax.microedition.location.LocationProvider;
import javax.microedition.location.QualifiedCoordinates;

import net.rim.device.api.system.EventLogger;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.GaugeField;
/**
 * This class extends the UiApplication class, providing a
 * graphical user interface.
 */
public class MyApp extends UiApplication
{
    /**
     * Entry point for application
     * @param args Command line arguments (not used)
     */
	int noExp=10;
    int persistentExp=10;
	public MyScreen screen;
	EditField filesizeField, url, httpVersionField, noOfExperiments;
	EditField  headGetField;
	ButtonField btn;
	GaugeField progressBar1,progressBar2,downloadBar1,downloadBar2,downloadBar3;
	ButtonField exp1Btn,exp1PersBtn,exp2Btn,exp3Btn;
	WgetClient wgetClient;
	Runnable r;
    public static void main(String[] args) throws IOException
    {
       //  Create a new instance of the application and make the currently
//         running thread the application's event dispatch thread.
         MyApp theApp = new MyApp();       
         theApp.enterEventDispatcher();
 //        Socket foo= new Socket("10.22.4.30", "3128");
                  
    }
    

    /**
     * Creates a new MyApp object
     */
    public static String arrayToString(int[] oa)
	{
		String s="[";
		for(int i=0;i<oa.length-1;i++)
		{
			s+=oa[i];
			s+=", ";
		}
		s+=oa[oa.length-1];
		s+="]";
		return s;
	}
    public static String arrayToString(float[] oa)
	{
		String s="[";
		for(int i=0;i<oa.length-1;i++)
		{
			s+=oa[i];
			s+=", ";
		}
		s+=oa[oa.length-1];
		s+="]";
		return s;
	}
    
    public static String arrayToString(int[][] oa)
	{
		String s="[";
		for(int i=0;i<oa.length-1;i++)
		{
			s+=arrayToString(oa[i]);
			s+=", ";
		}
		s+=oa[oa.length-1];
		s+="]";
		return s;
	}
    
    public static  String urlStringFromSize(String size)
	{
		String output="/~aseth/assg/bwtests/";
		if (size.equals("small"))
		{
			output+="great.txt";
		}
		else if(size.equals("mid"))
		{
			output+="paper-reading.pdf";
		}
		else if(size.equals("large"))
		{
			output+="giving-talks.pdf";
		}
		return output;
	}
    
    public void clearBars()
    {
    	progressBar1.setValue(0);
    	progressBar2.setValue(0);
    	downloadBar1.setValue(0);
    	downloadBar2.setValue(0);
    	downloadBar3.setValue(0);
    	screen.doPaint();
    }
    volatile double lati,longi;
    LocationProvider lp;
    Criteria crit=new Criteria();
    
    public MyApp() throws IOException
    {        
        // Push a screen onto the UI stack for rendering.
    	screen= new MyScreen();
    	try{
    		lp=LocationProvider.getInstance(crit);
    		//Dialog.alert("provider acquired");
    	}
    	catch(LocationException le)
    	{
    		Dialog.alert("location not supported");
    	}
    	lp.setLocationListener(new LocationListener() {
			
			public void providerStateChanged(LocationProvider provider, int newState) {
				// TODO Auto-generated method stub
				Dialog.alert("Location provider changed "+provider.toString());
				
			}
			
			public void locationUpdated(LocationProvider provider, Location location) {
				// TODO Auto-generated method stub
				Dialog.alert("position : ");
				try{lati=location.getQualifiedCoordinates().getLatitude();
				longi=location.getQualifiedCoordinates().getLongitude();}
				catch(NullPointerException npe)
				{
					//EventLogger.
				}
				Dialog.alert("position : "+lati+", "+longi);
			}
		}, -1, -1, -1);
     
/*    	filesizeField=new EditField("file size(small, mid or large) :", "small");
    	screen.add(filesizeField);
    	headGetField = new EditField("HEAD or GET: " ,"HEAD");
    	headGetField.setEditable(true);
        screen.add(headGetField);
        url=new EditField("URL to fetch: ", "http://www.google.co.in");
        screen.add(url);
        httpVersionField = new EditField("Http Version: ","1.0");
        screen.add(httpVersionField);
        noOfExperiments = new EditField("No. of experiments ","1");
        screen.add(noOfExperiments);
        btn = new ButtonField("download");
        btn.setChangeListener(new ButtonListener());
        screen.add(btn);
        */
                
                
        exp1Btn=new ButtonField("Latency Test:Non-Persistent");
        
        
        
        
        exp1Btn.setChangeListener(new FieldChangeListener() {
			
			public void fieldChanged(Field field, int context) {
				// TODO Auto-generated method stub
				clearBars();
				int[][] ans=wgetClient.latencyTestNonPersistent(urlStringFromSize("small"), noExp, 1);
				String ansString=arrayToString(ans);
				try{
				WgetClient.writeToFile("file://SDCard/nonperslatency.txt", ansString);
				
				Dialog.alert("querying the locations");
				//QualifiedCoordinates qc= lp.getLocation(60).getQualifiedCoordinates();
				//lati=qc.getLatitude();
				//longi=qc.getLongitude();
				//Dialog.alert("position : "+lati+", "+longi);
				
				}
				catch(Exception ioe)
				{
					Dialog.alert(ioe.toString());
				}
				Dialog.alert(ansString);
				
			}
		});
        
        exp1PersBtn=new ButtonField("Persistent latency test");
        
        exp1PersBtn.setChangeListener(new FieldChangeListener() {
			
			public void fieldChanged(Field field, int context) {
				// TODO Auto-generated method stub
				clearBars();
				int[][] ans=wgetClient.latencyTestNonPersistent(urlStringFromSize("small"), noExp, persistentExp);
				String ansString=arrayToString(ans);
				
				try{
					WgetClient.writeToFile("file:///SDCard/perslatency.txt", ansString);
					}
					catch(IOException ioe)
					{
						Dialog.alert(ioe.toString());
					}
				Dialog.alert(ansString);
				
			}
		});
        
        r= new Runnable() {
			
			public void run() {
				// TODO Auto-generated method stub
				
				try{
					Dialog.alert("Thread running");
					
				QualifiedCoordinates qc= lp.getLocation(60).getQualifiedCoordinates();
				lati=qc.getLatitude();
				longi=qc.getLongitude();
				}
				catch(Exception ie) {Dialog.alert(ie.toString());}
				
				Dialog.alert("position : "+lati+", "+longi);
			}
		};
        progressBar1=new GaugeField("latency test no: ", 0, noExp, 0, GaugeField.PERCENT);
        progressBar2=new GaugeField("Persistent no: ", 0, persistentExp, 0, GaugeField.PERCENT);
        downloadBar1=new GaugeField("Small Download : ", 0, WgetClient.size1, 0, GaugeField.PERCENT);
        downloadBar2=new GaugeField("mid.  Download : ", 0, WgetClient.size2, 0, GaugeField.PERCENT);
        downloadBar3=new GaugeField("large Download : ", 0, WgetClient.size3, 0, GaugeField.PERCENT);
        wgetClient=new WgetClient("socket://www.cse.iitd.ac.in:80;deviceside=true;apn=airtelgprs.com",progressBar1,progressBar2,downloadBar1,downloadBar2, downloadBar3,screen);
        screen.add(exp1Btn);
        screen.add(exp1PersBtn);
        filesizeField=new EditField("File size for test 2: ", "small");
        screen.add(filesizeField);
        exp2Btn=new ButtonField("Download rate");
        exp2Btn.setChangeListener(new FieldChangeListener() {
			
			public void fieldChanged(Field field, int context) {
				// TODO Auto-generated method stub
				Thread t=new Thread(r);
				t.start();
				clearBars();
				float[] results=wgetClient.downloadRateTest(10, filesizeField.getText());
				String resultStr=arrayToString(results);
				
				try{
					WgetClient.writeToFile("file:///SDCard/downRate_"+filesizeField.getText()+".txt", resultStr);
					
					
					
					}
					catch(Exception ioe)
					{
						Dialog.alert(ioe.toString());
					}
					

				
				if (results==null) Dialog.alert("null");				
				else{Dialog.alert(arrayToString(results));}
				
				
			}
		});
        screen.add(exp2Btn);
        screen.add(progressBar1);
        screen.add(progressBar2);
        screen.add(downloadBar1);
        screen.add(downloadBar2);
        screen.add(downloadBar3);
        pushScreen(screen);
        
        
    }   
}
