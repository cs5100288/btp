package mypackage;

import java.io.OutputStream;
import java.util.Date;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.EditField;

/**
 * This class extends the UiApplication class, providing a
 * graphical user interface.
 */
public class MyApp extends UiApplication
{
        private MyScreen _screen;
        private String Server_addr;
        private int _pairDist;
        private int _trainNumber;
        private int _trainSize;
        
    /**
     * Entry point for application
     * @param args Command line arguments (not used)
     */ 
    public static void main(String[] args) throws InterruptedException
    {
        MyApp theApp = new MyApp();       
        theApp.enterEventDispatcher();
    }
    
    ButtonField buttonPair, buttonTrain, runPair, runTrain;
    EditField pairDist, trainNumber, trainSize;
    /**
     * Creates a new MyApp object
     */
    public MyApp()
    {        
    	try
    	{
    		_screen = new MyScreen();
    		pushScreen(_screen)	;
//    		Server_addr = "datagram://192.168.1.3:9010";
    		Server_addr="datagram://124.124.247.5:9010/airtelgprs.com";
    		
    		buttonPair = new ButtonField("Run All Packet Pair Tests");
    		buttonTrain = new ButtonField("Run All Packet Train Tests");
    		pairDist = new EditField("Packet Separation in ms:", "100");
    		trainNumber = new EditField("Number of packets in train:", "10");
    		trainSize = new EditField("Packet Size of train:", "200");
    		runPair = new ButtonField("Run Pair Test");
    		runTrain = new ButtonField("Run Packet Train");
    		buttonPair.setChangeListener(new FieldChangeListener() {
				
				public void fieldChanged(Field field, int context) {
					try{
						packetPairWrapper();
					}
					catch (Exception e)
					{
			    		e.getMessage();
					}
										
				} 
			});
    		buttonTrain.setChangeListener(new FieldChangeListener() {
				
				public void fieldChanged(Field field, int context) {
					try{
					packetTrainWrapper();
					}
					catch (Exception e)
					{
			    		e.getMessage();
					}
				}
			});
    		runPair.setChangeListener(new FieldChangeListener() {
				
				public void fieldChanged(Field field, int context) {
					try{
						updateEntries();
						_screen.updateStatus("running packpair for delay="+_pairDist+"ms");
						packetPair(_pairDist, 5);
					}
					catch (Exception e)
					{
			    		e.getMessage();
					}
										
				} 
			});
    		runTrain.setChangeListener(new FieldChangeListener() {
				
				public void fieldChanged(Field field, int context) {
					try{
						updateEntries();
						_screen.updateStatus("running packet train for ("+_trainNumber+","+_trainSize+")");
						packetTrain(_trainNumber, _trainSize);
					}
					catch (Exception e)
					{
			    		e.getMessage();
					}
				}
			});
    		_screen.add(pairDist);
    		_screen.add(runPair);
    		_screen.add(trainNumber);
    		_screen.add(trainSize);
    		_screen.add(runTrain);
    		_screen.add(buttonPair);
    		_screen.add(buttonTrain);
    	}
    	
    	catch (Exception e)
		{
    		e.getMessage();
		}
    	
        
    }
    public void updateEntries()
	{
		_pairDist = Integer.parseInt(pairDist.getText());
		_trainNumber = Integer.parseInt(trainNumber.getText());
		_trainSize = Integer.parseInt(trainSize.getText());
	}
    	
    	public void packetPairWrapper() throws Exception 
    	{
    		for(int i=1;i<200;i+=2)
    		{	
    			_screen.updateStatus("running packpair for delay="+i+"ms");
    			packetPair(i, 1);
    			Thread.sleep(1000);
    		}
//    		Dialog.alert("Results written to packpair.txt");
    	}
    	public void packetTrainWrapper() throws Exception
    	{
    		int [] packlength= {20,50,80,100,150,200,300,400,500,600,700,800,900,1000};
    		for(int i = 3; i < 32; i += 2)
    		{
    			for ( int j=0;j<packlength.length;j++)
    			{
    				_screen.updateStatus("running packet train for ("+i+","+packlength[j]+")");
    				packetTrain(i,packlength[j]);    				
    				
    			}   
    		}
//    		Dialog.alert("Results written to packtrain.txt");
    	}
    	public void packetPair(int timeLag, int experiments) throws Exception
    	{
    		UdpClient first, second;
    		String s = "";
    		for (int i = 0; i < experiments; i++)
    		{
    			String sentence1 = "Method: ECHO\nId: " + 2*i + "\nSeqno: " + 1 + "\nLength: 128";
    			String sentence2 = "Method: ECHO\nId: " + (2*i+1) + "\nSeqno: " + 2 + "\nLength: 128";
    			first = new UdpClient(sentence1, _screen, Server_addr,false);
    			second = new UdpClient(sentence2, _screen, Server_addr,false);
    		
    			first.run();
    			Thread.sleep(timeLag);
    			second.run();
    		
    			s += String.valueOf(first.getSendTime())+","+String.valueOf(second.getSendTime())+","+String.valueOf(first.gettime_echo())+","+String.valueOf(second.gettime_echo())+"\n";
    		}
    		fileAdd("file:///SDCard/packpair.txt", s);
    	}
    	public void packetTrain (int packetNumber, int length) throws Exception
    	{
    		String s="";
    		int id=(int)(new Date()).getTime();
    		String sentence1 = "Method: ECHO\nId: " + id + "\nSeqno: " + 1 + "\nLength: 0";
    		String sentence2 = "Method: ECHO\nId: " + id + "\nSeqno: " + (packetNumber+2) + "\nLength: 0";
    		PacketTrain pt= new PacketTrain(_screen, Server_addr, id, length, packetNumber,sentence1,sentence2);
    		pt.runTrain();
    		String sentence = "Method: STAT\nId: " + id;
            UdpClient stat_udpclient=new UdpClient(sentence,_screen,Server_addr,false);
            stat_udpclient.run();
            Thread.sleep(1000);
            double[] stat_response=stat_udpclient.gettime_stat();
            _screen.updateStatus("got stat response\n");
            s+=length+","+packetNumber+",";
            s+=(stat_response[stat_response.length-1]-stat_response[0])+",";
            s+=(pt.sendtime2()-pt.sendtime1())+",";
            s+=String.valueOf(2-((stat_response[stat_response.length-1]-stat_response[0])/(pt.sendtime2()-pt.sendtime1())))+"\n";
            
    		fileAdd("file:///SDCard/packtrain.txt", s);
    		_screen.updateStatus("written to file ::"+s);
    	}
    	public void fileAdd(String filename, String data) throws Exception
    	{    		
//    		String roots="";
//    		Enumeration enum=FileSystemRegistry.listRoots();
//    		while(enum.hasMoreElements())
//    		{
//    			roots+=enum.nextElement()+"\n";
//    		}
//    		_screen.updateStatus(roots);
                    FileConnection fconn = (FileConnection)Connector.open(filename, Connector.READ_WRITE);
                    if(!fconn.exists()) fconn.create();
                    OutputStream os=fconn.openOutputStream(fconn.fileSize());
                    os.write(data.getBytes());
                    os.close();
                    fconn.close();
         }
    }    
