package in.ac.iitd.csl374;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;

public class BtContactService extends Service{
	DatabaseHelper dbHelper;
	volatile BluetoothAdapter mAdapter;
	String selfMac = "";
	Timer timer;
	private static final String DATABASE_CREATE =
        "create table if not exists btcontacts ("
        + "mac text not null primary key, time Integer);";
	private static final String DATABASE_DROP = 
		"drop table btcontacts";
    private static final String DATABASE_NAME = "data";
    private static final String DATABASE_TABLE = "btcontacts";
    private static final int DATABASE_VERSION = 2;
 


private class WebRequestTask extends AsyncTask<String, Integer, Long>


{
 @Override
protected Long doInBackground(String... arg0) {
	 HttpClient httpClient = new DefaultHttpClient();
	 HttpResponse response;
	 String responseString = "Default Null Response";
	 try{
		 String webAddr = "http://bluetoothlogs.gramvaani.org/insertentry.php?device1="+stringOfMac(selfMac)+"&device2="+stringOfMac(arg0[0]);
		 Log.e("Rajat", "Web Address: "+webAddr);
		 response=httpClient.execute(new HttpGet(webAddr));
		 StatusLine statusLine = response.getStatusLine();
         if(statusLine.getStatusCode() == HttpStatus.SC_OK){
             ByteArrayOutputStream out = new ByteArrayOutputStream();
             response.getEntity().writeTo(out);
             out.close();
             responseString = out.toString();
             Log.e("Rajat", "Response: "+responseString);
         } else{
             //Closes the connection.
             response.getEntity().getContent().close();
             Log.e("Rajat", "Not OK http status");
             throw new IOException(statusLine.getReasonPhrase());
         }
	 }
	 catch(Exception e)
	 {
		 Log.e("Rajat" , "Exception inside: "+e.toString());
		 
		 
	 }
	 
	// TODO Auto-generated method stub
	return null;
}
}


private static class DatabaseHelper extends SQLiteOpenHelper {




	public SQLiteDatabase mDb;
    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        mDb= this.getWritableDatabase();
        Log.e("Rajat", "Drop: "+DATABASE_DROP);
        //mDb.execSQL(DATABASE_DROP);
        Log.e("Rajat", DATABASE_CREATE);
        mDb.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    	
        
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w("Rajat", "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS btcontacts");
        onCreate(db);
    }
    public void add(String mac)
    {
    	//ContentValues cv=new ContentValues();
//    	cv.put("time", System.currentTimeMillis());
    	//cv.put("mac", mac);
    	String query= "insert or replace into "+DATABASE_TABLE+" (mac , time) values("+"'"+mac+"',"+System.currentTimeMillis()+")";
    	Log.e("Rajat", query);
    	mDb.execSQL(query);
    }
    public boolean isValid(String mac)
    {
    Log.e("Rajat","select * from "+DATABASE_TABLE+" where mac='"+mac+"'");
    Cursor cur= mDb.query(DATABASE_TABLE+" where mac='"+mac+"'",null,null,null,null,null,null);
    cur.moveToFirst();
    boolean enter=true;
    Log.e("Rajat","Checking if mac="+mac+"is valid");
    while(cur.isAfterLast()==false)
    {
    	enter=false;
    	
    	String lasttimeString = cur.getString(cur.getColumnIndex("time"));
    	long lasttime = Long.parseLong(lasttimeString);
    	Log.e("Rajat","Last time : "+lasttimeString);
    	if(System.currentTimeMillis()-lasttime>=5*60*1000/10)
    		enter=true;
    	cur.moveToNext();
    }
    return enter;
    }
    
}


public IBinder onBind(Intent arg0) {
	// TODO Auto-generated method stub
	return null;
}

@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.e("Rajat", "Service created");
		
		dbHelper= new DatabaseHelper(this.getApplication().getApplicationContext());

		this.detectBluetooth();
	    Log.e("Rajat","After detect bluetooth");
		
	}




@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		Log.e("Rajat", "Service Destroyed");	
		super.onDestroy();
		
	}




public void detectBluetooth()
{

//	Log.e("Rajat","Starting detectBluetooth");
	mAdapter= BluetoothAdapter.getDefaultAdapter();
	selfMac=mAdapter.getAddress();
	Log.e("Rajat","My Mac is : "+selfMac);
//	
//	Log.e("Rajat","Starting discovery");
	timer = new Timer();
	timer.schedule(new TimerTask() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Log.e("Rajat","Starting discovery");
			mAdapter.startDiscovery();
		}
	}, 300, 20000);
	
	Log.e("Rajat","After start discovery");
	
	// Create a BroadcastReceiver for ACTION_FOUND
	final BroadcastReceiver mReceiver = new BroadcastReceiver() {
	    public void onReceive(Context context, Intent intent) {
	        String action = intent.getAction();
	        // When discovery finds a device
	        if (BluetoothDevice.ACTION_FOUND.equals(action)) {
	            // Get the BluetoothDevice object from the Intent
	            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
	            // Add the name and address to an array adapter to show in a ListView
	            Log.e("Rajat" ,device.getName() + "::" + device.getAddress());
	            if(dbHelper.isValid(device.getAddress()))
	            {
	            	Log.e("Rajat", "valid");
	            	String address= device.getAddress();
	            	dbHelper.add(address);
	            	new WebRequestTask().execute(address);
	            }
	            else
	            {
	            	Log.e("Rajat", "invalid");
	            }
	        }
	    }
	};
	// Register the BroadcastReceiver
	IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
	registerReceiver(mReceiver, filter); // Don't forget to unregister during onDestroy
	
}
public String stringOfMac(String mac)
{
	return mac.replaceAll(":", "");
}







}
