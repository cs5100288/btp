package mypackage;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;

import javax.microedition.io.Connector;
import javax.microedition.io.SocketConnection;
import javax.microedition.io.file.FileConnection;
import javax.microedition.io.file.FileSystemRegistry;

import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.GaugeField;

public class WgetClient {
	
	String baseAddr;
	String username, password;
	String base64Auth;
	long timeDelay;
	public static int size1=1538;
	public static int size2=76717;
	public static int size3=5332570;
	 
	String responseText;
	int numBytes;
	float bandWidth;
	GaugeField progressBar1,progressBar2,db1,db2,db3;
	MyScreen screen;
	float progress=0;
	public WgetClient(String base, GaugeField progressBar1,GaugeField progressBar2, GaugeField db1, GaugeField db2, GaugeField db3, MyScreen screen) throws IOException
	
	{
	
	baseAddr=base;
	this.progressBar1=progressBar1;
	this.progressBar2=progressBar2;
	this.screen=screen;
	this.db1=db1;
	this.db2=db2;
	this.db3=db3;
	
		
	}
	public String getURL(String url, String httpVersion)
	{
		return requestURL("GET", url,httpVersion);
	}
	public String headURL(String url, String httpVersion)
	{
		return requestURL("HEAD", url, httpVersion);
	}
	public int getBytes()
	{
		int i=responseText.indexOf("Content-Length: ")+16;
		String temp=responseText.substring(i, responseText.length());
		int j=temp.indexOf("\n");
		String temp2=temp.substring(0, j);
		String temp3=temp2.trim();
		numBytes=Integer.parseInt(temp3);
		return numBytes;
		
	}
	
	
	
	public float getBandwidth()
	{
		bandWidth= ((float)numBytes)/timeDelay;
		bandWidth*=8.0;
		return bandWidth;
	}
	
	public String requestURL(String method, String url, String httpVersion)
	{
		String status="";
		try{
		 status+="before the first line\n";
       	 SocketConnection sc=(SocketConnection)Connector.open(baseAddr, Connector.READ_WRITE);
       	 status+="first line done\n";
       	 sc.setSocketOption(SocketConnection.LINGER,5);
       	 InputStream is =sc.openInputStream();
       	 OutputStream os=sc.openOutputStream();
       	 status+="open streams done\n";
       	 long timeBeforeRequest=System.currentTimeMillis();
       	 os.write((method+" "+url+" "+httpVersion+"\n").getBytes());
       	 //os.write(("Proxy-Authorization:Basic "+base64Auth).toString().getBytes());
       	 os.write("\n".getBytes());
       	 
       	 int ch=0;
       	 String s="";
       	 while(ch!=-1)
       	 {
       		 ch=is.read();
       		 s+=((char)ch);
       		 //progressBar.setValue(4);
       		 screen.doPaint();
       		 
       		 
       	 }
       	 long timeAfterRequest=System.currentTimeMillis();
       	 timeDelay=timeAfterRequest-timeBeforeRequest;
       	 responseText=s;
       	 is.close();
       	 os.close();
       	 sc.close();
       	 return method+"\n"+url+"\n"+httpVersion+"\n"+s;
       	 
        }
        
        catch(Exception e)
        {
       	  return e.toString()+" \nin getURL function, base address =  "+baseAddr+"status = "+status;
        }
        
	}
	public long getTimeDelay()
	{
		return timeDelay;
	}
	
	 private static String convertToHex(byte[] data) {
	        StringBuffer buf = new StringBuffer();
	        for (int i = 0; i < data.length; i++) {
	            int halfbyte = (data[i] >>> 4) & 0x0F;
	            int two_halfs = 0;
	            do {
	                if ((0 <= halfbyte) && (halfbyte <= 9))
	                    buf.append((char) ('0' + halfbyte));
	                else
	                    buf.append((char) ('a' + (halfbyte - 10)));
	                halfbyte = data[i] & 0x0F;
	            } while(two_halfs++ < 1);
	        }
	        return buf.toString();
	    }
	public String md5Hash(String data) throws UnsupportedEncodingException
	{
/*		MD5Digest digest= new MD5Digest();
		byte[] bytes=data.getBytes();
		digest.update(bytes,0,bytes.length);
		byte[] md5 = new byte[digest.getDigestLength()];
		digest.getDigest(md5,0,true);
	     return convertToHex(md5);
	*/    
		return data;
	}
	
	
	public static void appendToFile(String filename, String data) throws IOException
	{
		FileConnection fconn = (FileConnection)Connector.open(filename, Connector.READ_WRITE);
		if(!fconn.exists()) fconn.create();
		OutputStream os=fconn.openOutputStream();
		os.write(data.getBytes());
		os.close();
		fconn.close();
		
	}
	
	public static void writeToFile(String filename, String data) throws IOException
	{
		String roots="";
		Enumeration e= FileSystemRegistry.listRoots();
		
		while(e.hasMoreElements())
		{
			roots+=e.nextElement()+"\n";
		}
		Dialog.alert(roots);
		Dialog.alert("Writing to file "+filename);
		FileConnection fconn = (FileConnection)Connector.open(filename, Connector.READ_WRITE);
		//Dialog.alert("a");
		if(!fconn.exists()) fconn.create();
		//Dialog.alert("aa");
		OutputStream os=fconn.openOutputStream(fconn.fileSize());
		///Dialog.alert("aaa");
		os.write(data.getBytes());
		//Dialog.alert("aaaa");
		os.close();
		//Dialog.alert("aaaaa");
		fconn.close();
		//Dialog.alert("aaaaaa");
		//return 037;
	}
	
	
	
	public int[][] latencyTestNonPersistent(String url, int expTimes, int persistentTimes)
	{
		
			int[][] result=new int[expTimes][persistentTimes];
	//		Dialog.alert("entered test function");
			//progressBar1.set
			try{
			for(int j=0;j<expTimes;j++)
			{
	       	 SocketConnection sc=(SocketConnection)Connector.open(baseAddr, Connector.READ_WRITE);

	       	 //sc.setSocketOption(SocketConnection.LINGER,5);
	       	 sc.setSocketOption(SocketConnection.KEEPALIVE, 20);
	       	 InputStream is =sc.openInputStream();
	       	 OutputStream os;
	       	os=sc.openOutputStream();
	       	 long timeBeforeRequest,timeAfterRequest;
	       	 Dialog.alert("entering for loop");
	       	//progressBar2.setValue(0);
	       	 for(int i=0;i<persistentTimes;i++)
	       	 {
	       		 Dialog.alert("inside for loop");
	       	 
	       	 Dialog.alert("opened output stream");
	       	 timeBeforeRequest=System.currentTimeMillis();	       	 
	       	 os.write(("HEAD "+url+" HTTP/1.0\n").getBytes());
	       	 os.write("\n".getBytes());
	       	 Dialog.alert("written data to oStream");
	       	 os.flush(); 
	       	Dialog.alert("flush");
	       	String s="";
	       	 int ch=is.read();
	       	 while(ch!=-1)
	       	 {
	       		 s+=(char)ch;
	       		 ch=is.read();
	       		 //char chh=(char)ch;
	       		 //Dialog.alert(chh+"");
	       	 }
	       	 
	       	Dialog.alert("after is.read, char= ");
	       	Dialog.alert(s);
	       	 timeAfterRequest=System.currentTimeMillis();
	       	 timeDelay=timeAfterRequest-timeBeforeRequest;
	       	Dialog.alert("after determining delay");
	       	 result[j][i]=(int)timeDelay;
	       	Dialog.alert("arbit");
	       	 
	       	 //sc.cl
	       	//Dialog.alert("after os.close,setting value of bar1 "+ j);
	       	 progressBar1.setValue(j+1);
	       	Dialog.alert("setingvalue of bar2 "+ i);
	       	 progressBar2.setValue(i+1);
	       	Dialog.alert("before dopai");
	       	 screen.doPaint();
	       	 Dialog.alert("setting value of progress");
	       	 }
	       	os.close();
	       	is.close();
	       	sc.close();
			}
	       	 return result;
			}
			catch(Exception e)
			{
				Dialog.alert(e.toString()
						);
				return null;
			}
	        
	        
	        
	        
		}


			
public float[] downloadRateTest(int noTests, String urlsize)
{
	float [] result=new float[noTests];
	GaugeField db=db1;
	db1.setValue(0);
	db2.setValue(0);
	db3.setValue(0);
	//Dialog.alert("db1");
	if(urlsize.equals("mid"))
	{
		db=db2;
		//Dialog.alert("Db2");
	}
	else if(urlsize.equals("large"))
	{
		db=db3;
		//Dialog.alert("db3");
	}
	
	try{
		for(int j=0;j<noTests;j++)
		{
			//Dialog.alert("start");
       	 SocketConnection sc=(SocketConnection)Connector.open(baseAddr, Connector.READ_WRITE);

       	 //sc.setSocketOption(SocketConnection.LINGER,5);
       	 sc.setSocketOption(SocketConnection.LINGER, 5);
       	 InputStream is =sc.openInputStream();
       	 OutputStream os;
       	os=sc.openOutputStream();
       	 long timeBeforeRequest,timeAfterRequest;
       	 //Dialog.alert("entering for loop");
       	
       	
       	 
       	String url=MyApp.urlStringFromSize(urlsize);
       	timeBeforeRequest=System.currentTimeMillis();	       	 
       	os.write(("GET "+url+" HTTP/1.0\n").getBytes());
       	os.write("\n".getBytes());
       	//Dialog.alert("written data to oStream");
       	os.flush(); 
       	//Dialog.alert("flush");
       	String s="";
       	 int ch=is.read();
       	 while(ch!=-1)
       	 {
       		 //s+=(char)ch;
       		 ch=is.read();
       		 //Dialog.alert("value : "+db.getValue());
       		 //try{db.setValue(db.getValue()+1);}
       		 //catch(IllegalArgumentException iae) {}
       		//Dialog.alert("value : "+db.getValue());
       		 //db1.setValue(db1.getValue()+1);
       		 //screen.doPaint();
       		 //char chh=(char)ch;
       		 //Dialog.alert("yoo + ");
       	 }
       	 
       	//Dialog.alert("after is.read, char= "+s);
       	//Dialog.alert(s);
       	 timeAfterRequest=System.currentTimeMillis();
       	 timeDelay=timeAfterRequest-timeBeforeRequest;
       	
       	
       	
       	 result[j]=0.0f;
       	 //Dialog.alert(urlsize);
       	 
       	 if(urlsize.equals("small"))
       	 {
       		 //float arbit=(float)size1/(float)timeDelay;
       		 //Dialog.alert("size1 :"+size1+" timeDelay= "+timeDelay+" result="+arbit);
       		  
       		 result[j]=(float)size1/(float)timeDelay;
       		 
       	 }
       	 else if(urlsize.equals("mid"))
       	 {
       		result[j]=(float)size2/(float)timeDelay;
       	 }
       	 
       	 else if(urlsize.equals("large"))
       	 {
       		result[j]=(float)size3/(float)timeDelay;
       	 }
       	 result[j]*=8.0;
       	 //sc.cl
       	//ialog.alert("result value "+ result[j]);
       	
       	
       	os.close();
       	is.close();
       	sc.close();
       	progressBar1.setValue(j+1);
       	screen.doPaint();
		}
       	 return result;
		}
		catch(Exception e)
		{
			Dialog.alert(e.toString()
					);
			return null;
		}

	
	
	//return result;
}
	

}
